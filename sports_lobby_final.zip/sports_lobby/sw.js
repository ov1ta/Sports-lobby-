const CACHE_NAME = "sports-lobby-v2";

const STATIC_ASSETS = [
  "./",
  "./index.html",
  "./offline.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

// ─── Install: pre-cache static assets & skip waiting ─────────────────────────
self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

// ─── Activate: delete stale caches & claim clients immediately ────────────────
self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(keys =>
        Promise.all(
          keys
            .filter(key => key !== CACHE_NAME)
            .map(key => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

// ─── Fetch: route by request type ────────────────────────────────────────────
self.addEventListener("fetch", e => {
  const { request } = e;
  const url = new URL(request.url);

  // Skip non-GET requests and cross-origin requests
  if (request.method !== "GET" || url.origin !== self.location.origin) return;

  // API calls → Network-first, no caching
  if (url.pathname.startsWith("/api/")) {
    e.respondWith(networkOnly(request));
    return;
  }

  // Static assets → Cache-first with network fallback
  if (url.pathname.startsWith("/static/")) {
    e.respondWith(cacheFirst(request));
    return;
  }

  // Everything else (HTML, etc.) → Stale-while-revalidate
  e.respondWith(staleWhileRevalidate(request));
});

// ─── Strategies ──────────────────────────────────────────────────────────────

/** Cache-first: serve from cache; fetch & store if missing. */
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return offlineFallback(request);
  }
}

/** Stale-while-revalidate: serve cache immediately, update in background. */
async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);

  const fetchPromise = fetch(request)
    .then(response => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => null);

  return cached || fetchPromise || offlineFallback(request);
}

/** Network-only: always fetch, never cache. */
async function networkOnly(request) {
  try {
    return await fetch(request);
  } catch {
    return new Response(
      JSON.stringify({ error: "You are offline. Please try again later." }),
      { status: 503, headers: { "Content-Type": "application/json" } }
    );
  }
}

/** Fallback for offline HTML requests → /offline.html; others → 503. */
async function offlineFallback(request) {
  if (request.destination === "document") {
    const fallback = await caches.match("/offline.html");
    if (fallback) return fallback;
  }
  return new Response("Service unavailable while offline.", {
    status: 503,
    headers: { "Content-Type": "text/plain" },
  });
}
